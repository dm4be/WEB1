from django.urls import path
from App import views
from .views import old_page_redirect
from .views import random_quote


urlpatterns = [
   path('', views.index, name="home"),
   path('page/<int:page_id>/', views.page, name='page'),
   path('old-page/', old_page_redirect, name='old_page'),
   path("quote/", random_quote, name="random_quote"),
]
