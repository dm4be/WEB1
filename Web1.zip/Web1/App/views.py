from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
import random

QUOTES = [
    "Жизнь – это то, что с тобой происходит, пока ты строишь планы.",
    "Мудрость приходит не с возрастом, а с умением замечать ошибки.",
    "Лучший способ предсказать будущее – создать его.",
    "Не бойся идти медленно, бойся стоять на месте.",
    "Каждое великое достижение начинается с маленького шага."
]

def random_quote(request):
    quote = random.choice(QUOTES)
    return HttpResponse(quote)
def index(request):
    return HttpResponse("Главная страница!")
def page(request, page_id):
    return HttpResponse(f"<h1>Номер страницы:</h1><p>id:{page_id}</p>")
def number_view(request, num):
    return HttpResponse(f"Вы передали четное число: {num}")

def old_page_redirect(request):
    return redirect('home')

def error_404_view(request, exception):
    return HttpResponse("Ошибка 404: Страница не найдена", status=404)

def error_500_view(request):
    return HttpResponse("Ошибка 500: Внутренняя ошибка сервера", status=500)


# Create your views here.
