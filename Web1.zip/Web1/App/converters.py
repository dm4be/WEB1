class EvenNumberConverter:
    regex = r'\d+'

    def to_python(self, value):
        value = int(value)
        if value % 2 != 0:
            raise ValueError("Only even numbers are allowed")
        return value

    def to_url(self, value):
        return str(value)
